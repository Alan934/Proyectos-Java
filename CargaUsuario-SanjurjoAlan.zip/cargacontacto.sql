-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 12-06-2024 a las 16:13:42
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `cargacontacto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `apellido` varchar(25) NOT NULL,
  `dni` varchar(8) DEFAULT NULL,
  `pasaporte` varchar(25) DEFAULT NULL,
  `telefono` int(11) NOT NULL,
  `codigoPostal` int(11) NOT NULL,
  `domicilio` varchar(55) NOT NULL,
  `fechaActual` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `dni`, `pasaporte`, `telefono`, `codigoPostal`, `domicilio`, `fechaActual`) VALUES
(42, 'asd', 'ads', '12332123', NULL, 123123, 3213, '123', '2024-06-09'),
(45, 'qwe', 'qwe', '32132123', NULL, 123321, 1233, '123', '2024-06-09'),
(46, 'qwe', 'qwe', '32132124', NULL, 123321, 1233, '123', '2024-06-09'),
(47, 'qwe', 'qwe', '41232132', NULL, 123321, 1233, '123', '2024-06-09'),
(50, 'asd', 'asd', NULL, 'Q12332123', 123321, 1233, '123', '2024-06-09'),
(51, 'asd', 'asd', NULL, 'Q12332423', 123321, 1233, '123', '2024-06-09'),
(52, 'asd', 'asd', '12332155', NULL, 123321, 1233, '123', '2024-06-09'),
(53, 'asd', 'asd', NULL, 'R32132123', 123231, 1233, '312', '2024-06-09'),
(54, 'asd', 'asd', NULL, 'R32132124', 123231, 1233, '312', '2024-06-09'),
(55, 'asd', 'asd', '12332126', NULL, 123231, 1233, '312', '2024-06-09'),
(56, 'asd', 'asd', '12332144', NULL, 123321, 2323, '123', '2024-06-09'),
(57, 'asd', 'dsa', NULL, 'T12332123', 123231, 1233, '321', '2024-06-09'),
(58, 'asd', 'dsa', '43212343', NULL, 123231, 1233, '321', '2024-06-09'),
(59, 'asd', 'dsa', NULL, 'T12332126', 123231, 1233, '321', '2024-06-09'),
(60, 'asd', 'asd', '31342123', NULL, 123213, 2343, '', '2024-06-09'),
(61, 'Alan', 'Sanjurjo', '43749627', NULL, 123123, 1231, 'Casa', '2024-06-12'),
(62, 'Alan', 'Sanjurjo', NULL, 'S43749627', 123123, 1231, 'Casa', '2024-06-12');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

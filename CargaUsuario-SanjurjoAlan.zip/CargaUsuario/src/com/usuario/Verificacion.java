package com.usuario;

import javax.swing.JOptionPane;

public class Verificacion {
    private String nombre;
    private String apellido;
    private String dni;
    private String pasaporte;
    private int telefono;
    private int codigoPostal;
    private String domicilio;
    
    public Verificacion(String nombre, String apellido, String dni, String pasaporte, int telefono, int codigoPostal, String domicilio) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.pasaporte = pasaporte;
        this.telefono = telefono;
        this.codigoPostal = codigoPostal;
        this.domicilio = domicilio;
    }
    
    public boolean VerificarNombre(){
        try {
            if(nombre.length() <= 20 && nombre.matches("[a-zA-Z]+") && apellido.length() <= 20 && apellido.matches("[a-zA-Z]+") && nombre != null && apellido != null){
                return true;
            }else{            
                JOptionPane.showMessageDialog(null, "En el campo nombre solo puede tener 20 caracteres como maximo, y deben ser Letras", "Advertencia", 2);
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error al verificar el Nombre o Apellido: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }      
    }
    
    public boolean VerificarDni(){
        try {   
            if (dni == null || dni.isEmpty()) {
                return true; 
            }
            if (dni.length() == 8 && Integer.parseInt(dni) >= 10000000 && Integer.parseInt(dni) <= 60000000) {
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "El DNI debe tener 8 números y debe estar entre 10,000,000 y 60,000,000", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El DNI debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error al verificar el DNI: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public boolean VerificarPasaporte(){
        String DNI = String.valueOf(dni);
        String dniStr = DNI != null ? DNI.trim() : "";

        if (pasaporte == null || pasaporte.trim().isEmpty()) {
            if (!dniStr.isEmpty()) {
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Debe ingresar un valor en 'DNI' o 'Pasaporte'.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }

        try {
            int parteNumerica = Integer.parseInt(pasaporte.substring(1));
            if (pasaporte.matches("[A-Z]\\d{8}") && parteNumerica >= 10000000 && parteNumerica <= 60000000) {
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "El Pasaporte debe tener una única letra mayúscula, y seguido de 8 números que deben estar entre 10000000 a 60000000", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "La parte numérica del pasaporte no es válida", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return false;
        }
    }
    
    public boolean VerificarTelefono(){
        try {
            String regex = "^[+]?\\d{0,2}[\\s-]?\\(?\\d{0,5}\\)?[\\s-]?\\d{1,6}[\\s-]?\\d{1,7}$";
            String telefono = String.valueOf(this.telefono);
            if (telefono.matches(regex)) {
                int digitCount = telefono.replaceAll("\\D", "").length();

                if (digitCount >= 6) {
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "El teléfono debe tener al menos 6 dígitos numéricos.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                    return false;
                }
            } else {
                JOptionPane.showMessageDialog(null, "El formato del teléfono no es válido. Use solo dígitos numéricos, '+', '()', y '-'.", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error al verificar el Telefono: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public boolean VerificarCodigoPostal(){
        try {
            String codigoPostal = String.valueOf(this.codigoPostal);
            if (codigoPostal.length() == 4) {
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "El Codigo Postal debe tener 4 digitos numericos", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error al verificar el Telefono: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }     
    }
    
    public boolean VerificarDomicilio(){
        try {            
            if (domicilio.length() <= 50) {
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "El Domicilio debe tener menos de 50 caracteres", "Advertencia", JOptionPane.WARNING_MESSAGE);
                return false;
            }  
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocurrió un error al verificar el Domicilio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public boolean verificarDniOPasaporte() {
        boolean dniNoVacio = dni != null && !dni.trim().isEmpty();
        boolean pasaporteNoVacio = pasaporte != null && !pasaporte.trim().isEmpty();

        if (dniNoVacio && pasaporteNoVacio) {
            JOptionPane.showMessageDialog(null, "Solo uno de los campos 'DNI' o 'Pasaporte' puede tener un datos.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return false;
        } else if (!dniNoVacio && !pasaporteNoVacio) {
            JOptionPane.showMessageDialog(null, "Debe ingresar un valor en 'DNI' o 'Pasaporte'.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
    
}

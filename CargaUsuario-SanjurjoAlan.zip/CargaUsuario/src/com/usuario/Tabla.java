package com.usuario;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class Tabla extends javax.swing.JDialog{
    DefaultTableModel dtmUsuarios = new DefaultTableModel();
    ArrayList<Usuario>  listaUsuarios = new ArrayList<>();
    /*
    public TablaTable(java.awt.Frame parent, boolean modal){
        super(parent,modal);
        initComponents();
        setModelo();
    }
    
    private final List<String[]> usuarios;
    private final String[] columnNames = {"ID", "Nombre", "Apellido", "DNI", "Pasaporte", "Teléfono", "Código Postal", "Domicilio", "Fecha Actual"};

    public Tabla(List<String[]> usuarios) {
        this.usuarios = usuarios;
    }    

    
    public int getRowCount() {
        return usuarios.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return usuarios.get(rowIndex)[columnIndex];
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }*/
}

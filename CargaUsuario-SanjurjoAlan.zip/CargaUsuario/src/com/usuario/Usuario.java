package com.usuario;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Usuario implements IBasicoUsuario, IGestionUsuario{
    private int id;
    private String nombre;
    private String apellido;
    private String dni;
    private String pasaporte;
    private int telefono;
    private int codigoPostal;
    private String domicilio;

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public void setPasaporte(String pasaporte) {
        this.pasaporte = pasaporte;
    }
    
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public void setCodigoPostal(int codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }
    
    @Override
    public int getId() {
        return id;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public String getApellido() {
        return apellido;
    }

    @Override
    public String getDni() {
        return dni;
    }

    @Override
    public int getTelefono() {
        return telefono;
    }

    @Override
    public int getCodigoPostal() {
        return codigoPostal;
    }

    @Override
    public String getDomicilio() {
        return domicilio;
    }

    @Override
    public String getPasaporte() {
        return pasaporte;
    }
    
    @Override
    public void CargarUsuario() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/cargacontacto", "root", "");
            Statement sentencia = conexion.createStatement();
            ResultSet resultadosDNI, resultadosPasaporte;
            LocalDate fechaActual = LocalDate.now();

            resultadosDNI = sentencia.executeQuery("SELECT `dni` FROM `usuario` WHERE `dni` = '"+dni+"' AND `pasaporte` IS NULL;");

            if(resultadosDNI.next()){
                JOptionPane.showMessageDialog(null, "Usuario con el mismo DNI ya existe en la Base de Datos", "Advertencia", JOptionPane.WARNING_MESSAGE);
                resultadosDNI.close();
                sentencia.close();
                conexion.close();
                return;
            }

            resultadosPasaporte = sentencia.executeQuery("SELECT `pasaporte` FROM `usuario` WHERE `pasaporte` = '"+pasaporte+"' AND `dni` IS NULL;");

            if(resultadosPasaporte.next()){
                JOptionPane.showMessageDialog(null, "Usuario con el mismo pasaporte ya existe en la Base de Datos", "Advertencia", JOptionPane.WARNING_MESSAGE);
                resultadosPasaporte.close();
                sentencia.close();
                conexion.close();
                return;
            }

            if(dni == null){
                sentencia.executeUpdate("INSERT INTO `usuario`(`nombre`, `apellido`, `pasaporte`, `telefono`, `codigoPostal`, `domicilio`, `fechaActual`) VALUES ('"+nombre+"','"+apellido+"','"+pasaporte+"','"+telefono+"','"+codigoPostal+"','"+domicilio+"','"+fechaActual+"')");
                JOptionPane.showMessageDialog(null, "Usuario Cargado con Éxito");
            }else{
                sentencia.executeUpdate("INSERT INTO `usuario`(`nombre`, `apellido`, `dni`, `telefono`, `codigoPostal`, `domicilio`, `fechaActual`) VALUES ('"+nombre+"','"+apellido+"','"+dni+"','"+telefono+"','"+codigoPostal+"','"+domicilio+"','"+fechaActual+"')");
                JOptionPane.showMessageDialog(null, "Usuario Cargado con Éxito");
            }


            resultadosDNI.close();
            resultadosPasaporte.close();
            sentencia.close();
            conexion.close();
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public List<String[]> MostrarUsuarios() {
        List<String[]> usuarios = new ArrayList<>();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/cargacontacto", "root", "");
            Statement sentencia = conexion.createStatement();
            ResultSet resultados = sentencia.executeQuery("SELECT * FROM usuario");

            while (resultados.next()) {
                String[] usuario = new String[8];
                usuario[0] = resultados.getString("nombre");
                usuario[1] = resultados.getString("apellido");
                usuario[2] = resultados.getString("dni");
                usuario[3] = resultados.getString("pasaporte");
                usuario[4] = resultados.getString("telefono");
                usuario[5] = resultados.getString("codigoPostal");
                usuario[6] = resultados.getString("domicilio");
                usuario[7] = resultados.getString("fechaActual");
                usuarios.add(usuario);
            }

            resultados.close();
            sentencia.close();
            conexion.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }

        return usuarios;
    }
        /*try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/cargacontacto", "root", "");
            Statement sentencia = conexion.createStatement();
            ResultSet resultados;
            LocalDate fechaActual;

            resultados = sentencia.executeQuery("SELECT * FROM `usuario`;");
            
            ArrayList usuariosCargados = new ArrayList();
            
             
            
            sentencia.close();
            conexion.close();
        } catch (ClassNotFoundException | SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println(ex.getMessage());
        }*/
    //}


}

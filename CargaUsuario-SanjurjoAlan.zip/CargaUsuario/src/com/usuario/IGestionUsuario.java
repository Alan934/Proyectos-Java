package com.usuario;

import java.util.List;

public interface IGestionUsuario {
    void CargarUsuario();
    List<String[]> MostrarUsuarios();
}

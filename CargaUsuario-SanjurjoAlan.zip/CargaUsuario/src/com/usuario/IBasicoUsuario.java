package com.usuario;

public interface IBasicoUsuario {
    int getId();
    String getNombre();
    String getApellido();
    String getDni();
    String getPasaporte();
    int getTelefono();
    int getCodigoPostal();
    String getDomicilio();       
}

package chatsocket;

import views.PrincipalView;

/**
 *
 * @author Alan (Escritorio)
 */
public class ChatSocket {
    
    public static void main(String[] args) {
        PrincipalView principal = new PrincipalView();
        principal.setVisible(true);
    }
    
}
